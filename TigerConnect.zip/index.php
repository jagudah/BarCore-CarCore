<?php
$con = mysqli_connect("localhost", "root","") OR die("cannot connect");
$ver = mysqli_select_db($con, 'cp_connect') OR die("Selection error");
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>replit</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Trirong">
    <link href="signstyle.css" rel="stylesheet" type="text/css" />
    <script src="script.js"></script>
  </head>

  <body>
    <div class="logInContainer">
      <h1 style="font-size: 45px;"><img src="/images/car.png" alt="Car" style="width:150px;height:120px;margin-left:15px;">CP Connect</h1>
      <p>Admin Log In<hr></p>
      <div id="logIn" class="blurred-box"> 
        <form method="post">
          <label for="username" style=" position: relative;  left: 15%;">Username:</label>
          <input type="text" id="username" name="username" style=" position: relative;  left: 15%;"><br>
          <label for="password" style=" position: relative;  left: 15%;">Password:</label>
          <input type="password" id="password" name="password" style=" margin-top: 10px;position: relative;  left: 16%;"><br>
          <button type="button" onclick="location.assign('navLogin.html ');" style=" position: relative;  width: 80px; margin-left: 15px;">Navigator</button>
          <button type="button" onclick="location.assign('admin.html');">Log in</button>
        </form>
      </div>
    </div>
  </body>
</html>